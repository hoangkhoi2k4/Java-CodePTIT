
package object.j07058_danhSachMonThi;


public class Subject {
    private String id, name, type;

    public Subject(String id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }
    
    
}
