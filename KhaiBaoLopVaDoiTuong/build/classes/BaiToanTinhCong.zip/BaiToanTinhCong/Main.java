/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BaiToanTinhCong;
import java.util.*;
import BaiToanTinhCong.Employee;
/**
 *
 * @author Hoang Van Khoi
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Employee a = new Employee(sc.nextLine(), sc.nextLong(), sc.nextLong(), sc.next());
        System.out.println(a);
    }
}
//Bui Thi Trang
//45000
//23
//PGD