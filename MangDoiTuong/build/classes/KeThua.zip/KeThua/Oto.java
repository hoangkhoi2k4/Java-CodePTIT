/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KeThua;

/**
 *
 * @author Hoang Van Khoi
 */
public class Oto extends PTGT {
    private int soCho;
    private double dongCo;
    private static int soThuTu = 1;

    public Oto(String hang, String ngayLanBanh, double giaGoc, int soCho, double dongCo) {
        super(hang, ngayLanBanh, giaGoc);
        this.soCho = soCho;
        this.dongCo = dongCo;
    }

    public void setMa() {
        String hang = getHang().substring(0, 2).toUpperCase();
        setMa(hang + "-" + String.format("%03d", soThuTu++));
    }

    public double getGiaBan() {
        double giaBan = getGiaGoc();
        int soNam = tinhSoNamLanBanh();

        if (soNam == 0) {  // Năm nay, chỉ cần cộng thêm 10% thuế
            giaBan += giaBan * 0.1;
        } else if (soNam <= 2) {  // Nếu lăn bánh 1-2 năm, giảm 10%
            giaBan -= giaBan * 0.1;
        } else if (soNam <= 5) {  // Nếu lăn bánh 3-5 năm, giảm 20%
            giaBan -= giaBan * 0.2;
        } else {  // Nếu lăn bánh trên 5 năm, giảm 30%
            giaBan -= giaBan * 0.3;
        }

        return giaBan;
    }

    @Override
    public String toString() {
        // Định dạng lại giá bán về số nguyên không có phần thập phân
        return getMa() + " " + getHang() + " " + getNgayLanBanh() + " " + soCho + " " + (int)getGiaBan();
    }
}


