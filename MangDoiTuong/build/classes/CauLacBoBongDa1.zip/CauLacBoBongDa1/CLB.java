/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CauLacBoBongDa1;

/**
 *
 * @author Hoang Van Khoi
 */
public class CLB {
    private String ma, ten;
    private int gia;

    public CLB(String ma, String ten, int gia) {
        this.ma = ma;
        this.ten = ten;
        this.gia = gia;
    }

    public String getMa() {
        return ma;
    }

    public int getGia() {
        return gia;
    }

    public String getTen() {
        return ten;
    }
    
    
}
