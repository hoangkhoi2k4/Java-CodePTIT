/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MangDoiTuong;
import java.util.*;
/**
 *
 * @author Hoang Van Khoi
 */
public class Main {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        MS ms=new MS();
        ms.input(in);
        ms.out();
    }
}
//2
//123
//honda
//red
//2000
//12000
//444
//mec
//blue
//2024
//45000